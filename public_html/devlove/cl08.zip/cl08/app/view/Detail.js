Ext.define('ContactList.view.Detail', {

    extend: 'Ext.Panel',

    xtype: 'contactdetail',

    config: {
        styleHtmlContent: true,
        html: 'Detail Panel'
    }

});
